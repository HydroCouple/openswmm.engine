Rubinato 2017 comparison - visual supplement, 21 October 2026

Open rubinato2017_results.html in a browser for steady comparisons and T9 playback.
The HTML is self-contained and works offline. Its Download button exports plotted data.
PNG and SVG figures are identical to the manual figures; the PDF is printable review material.
Experimental qualification is incomplete. T9 forcing is synthetic, not measured transient data.
Source measurements: Rubinato et al. (2017), Table 2, DOI 10.1016/j.jhydrol.2017.06.024, CC BY 4.0.
See plotted_data.json for source hashes, numerical assumptions and binary identifiers.

Rubinato momentum smoothing follow-up, 22 October 2026.
Open docs/validation/rubinato2017/momentum_report.md; PNG/SVG figures and
all plotted data are included. No raw simulation outputs or logs.
Experimental agreement remains incomplete; convergence is assessed separately.
Reference: Rubinato et al. (2017), Journal of Hydrology 552, 421-432.
doi:10.1016/j.jhydrol.2017.06.024. Reference observations: CC-BY-4.0.
